package com.capgemini.go.bean;

public class RetailerInventoryBean {

}
