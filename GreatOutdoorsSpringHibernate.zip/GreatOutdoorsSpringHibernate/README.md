# GreatOutdoorsSpringHibernate
 Project developed on Spring MVC framework and JPA using Hibernate
