export class ReturnProduct{
    userid:string;
    prodid :string;
    orderid:string;
    prodqty:string;
    reason:string;
}