package com.capgemini.go.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/retailerInventory")
public class RetailerInventoryController {
	@RequestMapping(value = "/splash", method = RequestMethod.GET)
	public String printHello (ModelMap model) {
		model.addAttribute ("message", "Hello Spring MVC Framework!");
		return "hello";
	}
}
