//package com.capgemini.go.zpl;
//
//import com.capgemini.go.exception.ProductException;
//import com.capgemini.go.service.ProductService;
//import com.capgemini.go.service.ProductServiceImpl;
//
//public class ProductPL {
//	
//	public static void main(String[] args) {
//		
//		ProductService productService = new ProductServiceImpl();
//		try {
//			System.out.println(productService.viewAllProducts());
//		} catch (ProductException exp) {
//			
//			System.out.println(exp.getMessage());
//		}
//	}
//
//}
