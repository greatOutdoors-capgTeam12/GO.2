export class Address{
    addressId : string;
    building_number: string ;
    city: string ;
    state: string ;
    zip: string ;
    country: string ;
    address_status: boolean ;    
}