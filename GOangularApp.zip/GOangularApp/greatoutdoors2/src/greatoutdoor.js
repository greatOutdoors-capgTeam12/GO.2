$(function loadLightbox() {
    $("#mdb-lightbox-ui").load("mdb-addons/mdb-lightbox-ui.html");
    });